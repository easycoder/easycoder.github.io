# Examples #
## Image switcher /SHOW-IMAGESWITCHER/##
There are 9 images with only 1 showing. A row of thumbnail icons lets the user move left or right or select a specific image.
~<div id="ex-imageswitcher"></div>~
