class Error(Exception):
	def __init__(self, message):
		Exception.__init__(self, message)

class Script:
	def __init__(self, source):
		self.lines = source.splitlines()
		self.tokens = []

class Token:
	def __init__(self, lino, token):
		self.lino = lino
		self.token = token
