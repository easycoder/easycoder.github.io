 # EasyCoder server files
 
 These are mostly server-side files. The most significant are 2 small REST servers written in PHP and Python, which perform the same functions. The former is for setting up a `localhost` server and the latter is for use on LAMP servers.
