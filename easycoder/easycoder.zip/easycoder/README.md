 # EasyCoder server files
 
 These are mostly server-side files. In particular are small REST servers written in PHP and Python.
