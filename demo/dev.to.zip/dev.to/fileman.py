import bottle, subprocess, os, json
from bottle import Bottle, run, get, post, request, response, static_file

def HOST():
    return 'http://localhost:8080'

# start up the browser (version for Linux/Chromium)
cmd = f'chromium-browser {HOST()}/index-ec.html'
subprocess.call(cmd, shell=True)

app = Bottle()

###############################################################################
# Endpoints for the CodeUp demo

# CONTROLLER

# Endpoint: GET localhost:8080/flist/title
# List directories and files in the root directory
@app.get('/flist/<title>')
def flistroot(title):
    # Get the files in the named directory
    return flist(title, '')

# Endpoint: GET localhost:8080/flist/title/content
# List directories and files
@app.get('/flist/<title>/<name:path>')
def flist(title, name):
    # Get the files in the named directory
    flist = json.loads(listFiles(f'/{name}'))
    dirs = flist['dirs']
    files = flist['files']
    html = ''
    for file in dirs:
        if not file.startswith('.'):
            if name is '':
                path = file
            else:
                path = f'{name}/{file}'
            html += f'<div><a href="{HOST()}/flist/{title}/{path}">{file}</a></div>'
    html += '<br>'
    for file in files:
        if not file.startswith('.'):
            if name is '':
                path = file
            else:
                path = f'{name}/{file}'
            extension = os.path.splitext(file)[1]
            if extension == '.jpg' or extension == '.png' or extension == '.gif' or extension == '.mp3':
                html += f'<div>{file}</div>'
            else:
                html += f'<div><a href="{HOST()}/fview/{title}/{path}">{file}</a></div>'
    # Get the server template
    f = open('template/server.html', 'r')
    template = f.read()
    f.close()
    # Get the HTML to insert
    f = open(f'html/file-lister', 'r')
    content = f.read()
    f.close()
    content = content.replace('/DIR/', name).replace('/CONTENT/', html)
    return template.replace('/TITLE/', title).replace('/CONTENT/', content)

# Endpoint: GET localhost:8080/fview/title/content
# View a file
@app.get('/fview/<title>/<name:path>')
def fview(title, name):
    # Get the server template
    f = open('template/server.html', 'r')
    template = f.read()
    f.close()
    # Get the HTML to insert
    f = open(f'html/file-viewer', 'r')
    content = f.read()
    f.close()
    # Read the file and escape special characters
    file = readFile(name).replace('<', '&lt;').replace('>', '&gt;') \
        .replace('%09', '   ').replace('   ', '&nbsp;&nbsp;&nbsp;').replace('%0a', '<br>')
    content = content.replace('/FILE/', name).replace('/CONTENT/', file)
    return template.replace('/TITLE/', title).replace('/CONTENT/', content)

# MODEL

# Endpoint: GET localhost:8080/listfiles
# Lists all files in the system root directory
@app.get('/listfiles')
def listRoot():
    return listFiles('')

# Endpoint: GET localhost:8080/listfiles/name
# Lists all files in a specified directory
@app.get('/listfiles/<name:path>')
def listFiles(name):
    print(f'List files in {name}')
    dd = []
    ff = []
    for file in os.listdir(f'/{name}'):
        path = os.path.join(f'/{name if name else ""}', file)
        if os.path.isdir(path):
            #print(f'{path}: dir')
            dd.append(file)
        else:
            #print(f'{path}: file')
            ff.append(file)
    dd.sort()
    ff.sort()
    d = json.dumps(dd)
    f = json.dumps(ff)
    return '{"dirs":' + d + ',"files":' + f + '}'

# Endpoint: GET localhost:8080/readfile/content
# Read a file
@app.get('/readfile/<name:path>')
def readFile(name):
    f = open(f'/{name}', 'r')
    file = f.read().replace('\t', '%09').replace('\n', '%0a');
    f.close()
    return file

###############################################################################
# Endpoints for EasyCoder script editing

# Endpoint: GET localhost:8080/listScripts
# Lists all files in the scripts directory
@app.get('/listScripts')
def listScripts():
    print("List scripts")
    dd = []
    ff = []
    for file in os.listdir("scripts"):
        if os.path.isdir(os.path.join('scripts', file)):
            dd.append(file)
        else:
            ff.append(file)
    d = json.dumps(dd)
    f = json.dumps(ff)
    return '{"dirs":' + d + ',"files":' + f + '}'

# Endpoint: GET localhost:8080/getScript/<filename>
# Gets a named script from the scripts directory
@app.get('/getScript/<filename:path>')
def getScript(filename):
    print(f'Get ./scripts/{filename}')
    response = bottle.static_file(filename, root='./scripts')
    response.set_header("Cache-Control", "public, max-age=0")
    return response

# Endpoint: POST localhost:8080/saveScript/<filename>
# Writes the POST body to a named file in the scripts directory
@app.post('/saveScript/<filename:path>')
def saveScript(filename):
    path = f'./scripts/{filename}'
    print(f'Save {path}')
    f = open(path, 'w+')
    f.write(request.body.read().decode('utf-8'))
    f.close()
    return

# Endpoint: POST localhost:8080/deleteScript/<filename>
# Deletes a named script in the scripts directory
@app.post('/deleteScript/<filename:path>')
def deleteScript(filename):
    path = f'./scripts/{filename}'
    print(f'Delete {path}')
    os.remove(path)
    return

###############################################################################
# Endpoints for HTML file editing

# Endpoint: GET localhost:8080/listHTML
# Lists all files in the html directory
@app.get('/listHTML')
def listHTML():
    print("List html files")
    dd = []
    ff = []
    for file in os.listdir("html"):
        if os.path.isdir(os.path.join('html', file)):
            dd.append(file)
        else:
            ff.append(file)
    d = json.dumps(dd)
    f = json.dumps(ff)
    return '{"dirs":' + d + ',"files":' + f + '}'

# Endpoint: GET localhost:8080/getHTML/<filename>
# Gets a named file from the html directory
@app.get('/getHTML/<filename:path>')
def getHTML(filename):
    print(f'Get ./html/{filename}')
    response = bottle.static_file(filename, root='./html')
    response.set_header("Cache-Control", "public, max-age=0")
    return response

# Endpoint: POST localhost:8080/saveHTML/<filename>
# Writes the POST body to a named file in the html directory
@app.post('/saveHTML/<filename:path>')
def saveHTML(filename):
    path = f'./html/{filename}'
    print(f'Save {path}')
    f = open(path, 'w')
    f.write(request.body.read().decode('utf-8'))
    f.close()
    return

# Endpoint: POST localhost:8080/deleteHTML/<filename>
# Deletes a named file in the html directory
@app.post('/deleteHTML/<filename:path>')
def deleteHTML(filename):
    path = f'./html/{filename}'
    print(f'Delete {path}')
    os.remove(path)
    return

###############################################################################
# Generic endpoints

# Endpoint: GET localhost:8080/<path>
# Gets a file
@app.get('/<filename:path>')
def getFile(filename):
    print(f'Get {filename}')
    response = bottle.static_file(filename, root='.')
    response.set_header("Cache-Control", "public, max-age=0")
    return response

# Endpoint: GET localhost:8080>
# Gets the default home page
@app.get('/')
def index():
    return getFile('index.html')

if __name__ == '__main__':
    app.run()
