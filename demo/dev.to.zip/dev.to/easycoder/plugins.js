const EasyCoder_Plugins = {
    getGlobalPlugins: (timestamp, path, setPluginCount, getPlugin, addPlugin) => {
        console.log(`${Date.now() - timestamp} ms: Load plugins`);
        setPluginCount(3);
        getPlugin(`browser`, `./easycoder/plugins/browser.js`, function () {
                addPlugin(`browser`, EasyCoder_Browser);
            });
        getPlugin(`json`, `./easycoder/plugins/json.js`, function () {
                addPlugin(`json`, EasyCoder_Json);
            });
        getPlugin(`rest`, `./easycoder/plugins/rest.js`, function () {
                addPlugin(`rest`, EasyCoder_Rest);
            });
    },
    rest: () => {
        return ``;
    }
};
