### Here On The Map - a demo website ###

[Here On The Map](https://hereonthemap.com) is a website that shows off the capabilities of **_EasyCoder_**. It is a 100% scripted website; single-page and driven from the browser. All of its scripts are included in this repository, in the "scripts" folder.

The purpose of Here On The Map is to demonstrate that website coding need not be complex. In fact, for the majority of websites you don't need to learn JavaScript, let alone any of the over-complicated frameworks that have become de _rigeur_ for anyone wanting to show off their programming skills, but which generally leave a website in an un-maintainable state.

There's a reason why React exists; it's so Facebook could manage development of one of the world's largest websites. Are you building a website of a similar complexity and size to Facebook? Probably not. So is the toolkit they developed necessarily the best for you too? Getting the right answer to this question could save you a massive amount of time and effort.

(more to follow)
