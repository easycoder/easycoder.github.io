# ~ec~ Contacts #

Here are some ~ec~ contact options:

1. Email to [info@easycoder.software](mailto:info@easycoder.software)

1. Contact the author on [Fleep Messenger](graham.trott@fleep.io).

1. Join our [Slack channel](https://join.slack.com/t/easycoder-software/shared_invite/enQtNTU5ODEwOTQ5NTU0LWQ1NWVkOTUxOGQ3NzJmNDI1ZGRlOTdmMjc1NDAxMGIwMTFjODg1ZDJhODEzMzUzODc2MDNlZWU4NmYyZWRlOWI).
