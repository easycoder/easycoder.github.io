# example1 - Concertina #
This is a simple example of how to display sections of a page while hiding the rest.

~html:&lt;div id="container"&gt;This is the container&lt;/div&gt;
